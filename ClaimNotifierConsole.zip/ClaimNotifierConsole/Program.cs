using Microsoft.Extensions.Configuration;
using ClaimNotifierConsole.Helpers;
using ClaimNotifierConsole.Services;
using ClaimNotifierConsole.Interfaces;
using ClaimNotifierConsole.Core;

class Program
{
    static void Main(string[] args)
    {
        IConfiguration config = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
            .Build();

        var settings = config.Get<AppSettings>();

        IDatabaseService dbService = new SqlDatabaseService(settings.Database.ConnectionString);
        IEmailService emailService = new SmtpEmailService(
            settings.Email.SmtpHost,
            settings.Email.SmtpPort,
            settings.Email.SmtpUser,
            settings.Email.SmtpPass,
            settings.Email.FromEmail
        );

        var processor = new ClaimProcessor(dbService, emailService);
        processor.Execute();
    }
}
