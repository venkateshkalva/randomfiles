using ClaimNotifierConsole.Models;
namespace ClaimNotifierConsole.Interfaces
{
    public interface IDatabaseService
    {
        (List<ClaimRecord> Claims, string EmailContent) GetClaimsAndEmailContent();
    }
}
