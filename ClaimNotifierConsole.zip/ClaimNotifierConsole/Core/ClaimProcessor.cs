using ClaimNotifierConsole.Interfaces;

namespace ClaimNotifierConsole.Core
{
    public class ClaimProcessor
    {
        private readonly IDatabaseService _dbService;
        private readonly IEmailService _emailService;

        public ClaimProcessor(IDatabaseService dbService, IEmailService emailService)
        {
            _dbService = dbService;
            _emailService = emailService;
        }

        public void Execute()
        {
            var (claims, emailTemplate) = _dbService.GetClaimsAndEmailContent();

            foreach (var claim in claims)
            {
                string personalized = emailTemplate.Replace("{Name}", claim.Name);
                _emailService.SendEmail("recipient@example.com", "Your Claim Update", personalized);
            }

            Console.WriteLine("All emails sent.");
        }
    }
}
