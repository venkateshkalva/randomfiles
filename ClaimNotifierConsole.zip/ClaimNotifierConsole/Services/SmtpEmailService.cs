using System.Net;
using System.Net.Mail;
using ClaimNotifierConsole.Interfaces;

namespace ClaimNotifierConsole.Services
{
    public class SmtpEmailService : IEmailService
    {
        private readonly string _host;
        private readonly int _port;
        private readonly string _user;
        private readonly string _pass;
        private readonly string _from;

        public SmtpEmailService(string host, int port, string user, string pass, string from)
        {
            _host = host;
            _port = port;
            _user = user;
            _pass = pass;
            _from = from;
        }

        public void SendEmail(string to, string subject, string body)
        {
            using var client = new SmtpClient(_host, _port)
            {
                Credentials = new NetworkCredential(_user, _pass),
                EnableSsl = true
            };

            var message = new MailMessage(_from, to, subject, body)
            {
                IsBodyHtml = true
            };

            client.Send(message);
        }
    }
}
