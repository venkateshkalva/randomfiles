using System.Data;
using System.Data.SqlClient;
using ClaimNotifierConsole.Interfaces;
using ClaimNotifierConsole.Models;

namespace ClaimNotifierConsole.Services
{
    public class SqlDatabaseService : IDatabaseService
    {
        private readonly string _connectionString;

        public SqlDatabaseService(string connectionString)
        {
            _connectionString = connectionString;
        }

        public (List<ClaimRecord>, string) GetClaimsAndEmailContent()
        {
            var claims = new List<ClaimRecord>();
            string emailContent = string.Empty;

            using var conn = new SqlConnection(_connectionString);
            using var cmd = new SqlCommand("usp_GetClaimDataAndEmail", conn)
            {
                CommandType = CommandType.StoredProcedure
            };

            conn.Open();
            using var reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                claims.Add(new ClaimRecord
                {
                    Id = Convert.ToInt32(reader["Id"]),
                    Name = reader["Name"].ToString()
                });
            }

            if (reader.NextResult() && reader.Read())
            {
                emailContent = reader["EmailContent"].ToString();
            }

            return (claims, emailContent);
        }
    }
}
